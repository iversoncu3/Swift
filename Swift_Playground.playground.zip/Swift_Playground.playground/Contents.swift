import UIKit

// Ilk Kod
var str = "Magnetron Defence and Space"
var yas = 5
print(str)
print(yas)

// Degisken turunu belirleme
var str1 = "Baraday"
var str2 :String = "Magnetron" // Burda degisken turunu biz belirttik
print(str1)
print(str2)

// String Birlestirme
var ad = "Baran"
var soyAd = "Akbiyik"
var ad_soyAd = ad + " " + soyAd
print(ad_soyAd)

// Print Icerisinde String Yazdirma
var ad1 = "Baraday"
var soyAd1 = "Magnetron"
print ("Adim \(ad1) Soyadim \(soyAd)")

// Satirlar ile String Tanimlama

var dortluk = """
Bu araliklara yazilan hersey artik string
Satir2
Satir3
Satir4
"""

// String arayip degistirme
ad_soyAd = "Cimbom Galatasaray"
ad_soyAd = ad_soyAd.replacingOccurrences(of: "bom", with: "BOM BOM")
print(ad_soyAd)

// Stringi sonuna ekleme
var sehir = "Ankara"
sehir.append(" ve Istanbul cok guzel bir sehir")
print(sehir)

// Harfleri Buyultup, Kucultme
sehir.uppercased()
sehir.lowercased()

let ad333 = "Baran"
let dogumYili : Int = 19

print ("INT8 max degeri \(Int8.max)")
print ("INT8 max degeri \(Int8.min)")

print ("INT16 max degeri \(Int16.max)")
print ("INT16 max degeri \(Int16.min)")

print ("INT32 max degeri \(Int32.max)")
print ("INT32 max degeri \(Int32.min)")

print ("INT64 max degeri \(Int64.max)")
print ("INT64 max degeri \(Int64.min)")


// command + / butun satiri yorum yapiyor

var deger1 : Bool = Bool(truncating: 1)
var deger2 : Bool = false

